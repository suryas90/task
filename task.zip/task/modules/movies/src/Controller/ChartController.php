<?php

namespace Drupal\movies\Controller;

use Drupal\Core\Controller\ControllerBase;

class ChartController extends ControllerBase {

  public function showChart() {	
	
	$nids = db_query("SELECT nid FROM {node} WHERE type = :type", array(':type' => 'movie'))
    ->fetchCol();
	
	$gross_data = "Genre Version	Gross collection \n";
	foreach($nids as $nid){
		$node = node_load($nid);
		$field_genre = $node->get('field_genre')->getValue();
		$field_genre_id = $field_genre[0]['target_id'];
		
		$term = \Drupal::entityTypeManager()->getStorage('taxonomy_term')->load($field_genre_id);
		$name = $term->label();

		$field_gross_collection = $node->get('field_gross_collection')->getValue();
		$field_gross_collection_id = $field_gross_collection[0]['value'];
		
		$gross_data .= $name." ". $field_gross_collection_id. "x	". $field_gross_collection_id."% \n";
		
	}
	
    return [
      '#theme' => 'high_chart',
	  '#gross_data' => $gross_data,
	  '#attached' => [
			'library' => [
			  'movies/movies',
			],
      ],
    ];
  }

}